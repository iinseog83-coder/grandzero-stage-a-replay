import StageA

open GrandZero.StageA

def formatVerdict (s : SyndromeQ0) : String :=
  if s == SyndromeQ0.zero then
    "PASS (SyndromeQ0.zero)"
  else
    s!"REJECT (scope={s.illTypedOrScopeError}, unit={s.unitOrKindMismatch}, " ++
    s!"pole={s.unguardedPoleLeak}, poly={s.polynomialResidualNonZero}, " ++
    s!"guard={s.invalidGuardOrHypProof}, bind={s.structuralBindMismatch})"

def main : IO Unit := do
  IO.println "=================================================================="
  IO.println "GRANDZERO Ω — Stage A (M1-P0 R3) Isolated Kernel Execution Audit"
  IO.println "=================================================================="

  let s01 := auditProof xt01_ctx [] [] (.gprLoweredTapeCert [] []) xt01_lhs xt01_rhs
  let obs01 := checkObstruction xt01_ctx [] [] [0] xt01_lhs xt01_rhs
  IO.println s!"[XT-01] Expected: EXPECTED_REJECT | Actual: {formatVerdict s01} | Obstruction(ρ=[0])={obs01}"

  let s02 := auditProof xt02_ctx [] xt02_guards (.gprLoweredTapeCert [.gActiveMem 0] []) xt02_lhs xt02_rhs
  let obs02 := checkObstruction xt02_ctx [] xt02_guards [-1] xt02_lhs xt02_rhs
  IO.println s!"[XT-02] Expected: EXPECTED_REJECT | Actual: {formatVerdict s02} | Obstruction(ρ=[-1])={obs02}"

  let s03_ast := auditProof xt03_ctx [] xt03_guards (.gprAstCert xt03_proofs []) xt03_lhs xt03_rhs
  let s03_ssa := auditProof xt03_ctx [] xt03_guards (.gprLoweredTapeCert xt03_proofs []) xt03_lhs xt03_rhs
  IO.println s!"[XT-03] Expected: EXPECTED_PASS   | Actual(AST): {formatVerdict s03_ast} | Actual(SSA): {formatVerdict s03_ssa}"

  let s04 := auditProof xt04_ctx [] xt04_guards (.gprLoweredTapeCert [.gActiveMem 0] []) xt04_lhs xt04_rhs
  IO.println s!"[XT-04] Expected: EXPECTED_REJECT | Actual: {formatVerdict s04}"

  let s05 := auditProof xt05_ctx [] [] (.gprLoweredTapeCert [] []) xt05_lhs xt05_rhs
  IO.println s!"[XT-05] Expected: EXPECTED_REJECT | Actual: {formatVerdict s05}"

  let s06 := auditProof xt06_ctx [] xt06_guards
    (.gprRawTapeCert xt06_raw_tape 10 12 [.gActiveMem 0] [.gActiveMem 0])
    xt06_lhs xt06_rhs
  IO.println s!"[XT-06] Expected: EXPECTED_PASS   | Actual(RawSSA+DeadRow): {formatVerdict s06}"

  let sTrA := auditProof traceA_ctx [] [] (.gprLoweredTapeCert [] []) traceA_lhs traceA_rhs
  IO.println s!"[TraceA] let y := x_0 + 1_m in y = x_0 + 1_m | Actual: {formatVerdict sTrA}"

  let sTrB_ast := auditProof traceB_ctx [] traceB_guards (.gprAstCert [.gActiveMem 0] [.gActiveMem 0]) traceB_lhs traceB_rhs
  let sTrB_ssa := auditProof traceB_ctx [] traceB_guards (.gprLoweredTapeCert [.gActiveMem 0] [.gActiveMem 0]) traceB_lhs traceB_rhs
  IO.println s!"[TraceB] let y := 1/x_0 in y+y = 2/x_0 | AST: {formatVerdict sTrB_ast} | SSA: {formatVerdict sTrB_ssa}"

  let sTrC_dead := auditProof [] [] [] (.gprRawTapeCert traceC_dead_tape 3 3 [] []) traceC_five traceC_five
  let sTrC_let  := auditProof [] [] [] (.gprLoweredTapeCert [] []) traceC_strict_let_pole traceC_five
  let obsTrC    := checkObstruction [] [] [] [] traceC_strict_let_pole traceC_five
  IO.println s!"[TraceC] DeadRow(1/0, root=5): {formatVerdict sTrC_dead} | StrictLet(let y:=1/0 in 5): {formatVerdict sTrC_let} (Obstruction={obsTrC})"

  let allMatch : Bool :=
    (s01 != SyndromeQ0.zero) && obs01 &&
    (s02 != SyndromeQ0.zero) && obs02 &&
    (s03_ast == SyndromeQ0.zero) && (s03_ssa == SyndromeQ0.zero) &&
    (s04 != SyndromeQ0.zero) &&
    (s05 != SyndromeQ0.zero) &&
    (s06 == SyndromeQ0.zero) &&
    (sTrA == SyndromeQ0.zero) &&
    (sTrB_ast == SyndromeQ0.zero) && (sTrB_ssa == SyndromeQ0.zero) &&
    (sTrC_dead == SyndromeQ0.zero) && (sTrC_let != SyndromeQ0.zero) && obsTrC

  if allMatch then
    IO.println "------------------------------------------------------------------"
    IO.println "ALL STAGE A ADVERSARIAL & COMMUTATION VECTORS MATCH EXPECTED: TRUE"
    IO.println "=================================================================="
  else
    throw (IO.userError "Vector mismatch detected!")
