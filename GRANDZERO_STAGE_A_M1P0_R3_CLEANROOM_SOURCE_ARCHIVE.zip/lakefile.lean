import Lake
open Lake DSL

package «gz_stage_a_m1_p0_q0» where
  leanOptions := #[
    ⟨`autoImplicit, false⟩
  ]

lean_lib «StageA» where
  roots := #[`StageA]

@[default_target]
lean_exe «stage_a_audit» where
  root := `Main
